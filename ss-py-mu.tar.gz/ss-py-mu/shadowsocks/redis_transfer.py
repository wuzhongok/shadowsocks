#!/usr/bin/python
# -*- coding: UTF-8 -*-

import logging
import redis
import time
import sys
from server_pool import ServerPool
import Config
from redisClient import RedisClient

class RedisTransfer(object):

    instance = None

    def __init__(self):
        self.last_get_transfer = {}

    @staticmethod
    def get_instance():
        if RedisTransfer.instance is None:
            RedisTransfer.instance = RedisTransfer()
        return RedisTransfer.instance


    @staticmethod
    def syncEnableUsers():
        logging.info('start syncEnableUsers ......')
        list = RedisClient.GetUserPreEnableList()
        for port in list:
            if port == '' or port < 1 :
                logging.error('Invalid Port : %s' % (port))
                RedisClient.RmFromUserPreEnableList(port)
                continue
            userInfo = RedisClient.GetUserInfo(port)

            if userInfo is None :
                logging.error('userInfo is not exists , port : %s' % (port))
                RedisClient.RmFromUserPreEnableList(port)
                continue

            passwd = userInfo['Passwd']
            logging.info('start server at port [%s] pass [%s]' % (port, passwd))
            ServerPool.get_instance().new_server(port,passwd)
            RedisClient.SetUserAsEnable(port)
            RedisClient.RmFromUserPreEnableList(port)
        logging.info('finish syncEnableUsers ......')

    @staticmethod
    def syncDisableUsers():
        logging.info('start syncDisableUsers ......')
        list = RedisClient.GetUserPreDisableList()
        for port in list:
            logging.info('stop server at port [%s] reason: disable' % (port))
            ServerPool.get_instance().del_server(port)
            RedisClient.RmFromUserPreDisableList(port)
            RedisClient.SetUserAsDisabled(port)
        logging.info('finish syncDisableUsers ......')

    def syncTraficAndPasswd(self):
        logging.info('start syncTraficAndPasswd ......')
        #更新用户流量到数据库
        last_transfer = self.last_get_transfer
        curr_transfer = ServerPool.get_instance().get_servers_transfer()
        #上次和本次的增量
        dt_transfer = {}
        for port in curr_transfer.keys():
            if port in last_transfer:
                if last_transfer[port][0] == curr_transfer[port][0] and last_transfer[port][1] == curr_transfer[port][1]:
                    continue
                elif curr_transfer[port][0] == 0 and curr_transfer[port][1] == 0:
                    continue
                elif last_transfer[port][0] <= curr_transfer[port][0] and \
                last_transfer[port][1] <= curr_transfer[port][1]:
                    dt_transfer[port] = [curr_transfer[port][0] - last_transfer[port][0],
                                       curr_transfer[port][1] - last_transfer[port][1]]
                else:
                    dt_transfer[port] = [curr_transfer[port][0], curr_transfer[port][1]]
            else:
                if curr_transfer[port][0] == 0 and curr_transfer[port][1] == 0:
                    continue
                dt_transfer[port] = [curr_transfer[port][0], curr_transfer[port][1]]

        self.last_get_transfer = curr_transfer
        for port in dt_transfer.keys():
            size = int(dt_transfer[port][0]) + int(dt_transfer[port][1])
            logging.info('port : {} , incr size : {}'.format(port,size))
            RedisClient.IncrSize(port,size)
            if ServerPool.get_instance().server_is_run(port) is True :
                userInfo = RedisClient.GetUserInfo(port)
                if userInfo is not None and ServerPool.get_instance().tcp_servers_pool[port]._config['password'] != userInfo['Passwd'] :
                    #password changed
                    logging.info('stop server at port [%s] reason: password changed' % (port))
                    ServerPool.get_instance().del_server(port)

        logging.info('finish syncTraficAndPasswd ......')

    @staticmethod
    def initUsers():
        u1 = { 'Port' : '7001' , 'Passwd' : '123456' , 'Method' : 'rc4-md5'}
        u2 = { 'Port' : '7002' , 'Passwd' : '123456' , 'Method' : 'rc4-md5'}
        u3 = { 'Port' : '7003' , 'Passwd' : '123456' , 'Method' : 'rc4-md5'}
        RedisClient.StoreUserInfo(u1)
        RedisClient.StoreUserInfo(u2)
        RedisClient.StoreUserInfo(u3)
        RedisClient.AddToUserPreEnableList('7001')

    @staticmethod
    def thread_start():
        import socket
        import time
        timeout = 60
        socket.setdefaulttimeout(timeout)

        #RedisTransfer.initUsers()

        while True:
            #logging.warn('db loop')
            try:
                RedisTransfer.syncEnableUsers()
                RedisTransfer.syncDisableUsers()
                RedisTransfer.get_instance().syncTraficAndPasswd()
            except Exception as e:
                logging.warn('thread_start thread except:%s' % e)
            finally:
                time.sleep(30)
