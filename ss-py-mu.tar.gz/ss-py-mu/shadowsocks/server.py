import time
import sys
import thread
import server_pool
from redis_transfer import RedisTransfer
from redisClient import RedisClient


if __name__ == '__main__':

    thread.start_new_thread(RedisTransfer.thread_start, ())
    #"""
    #time.sleep(2)
    #server_pool.ServerPool.get_instance().new_server(3333, '2333')
    #while True:
    #    server_pool.ServerPool.get_instance().new_server(2333, '2333')
    #    server_pool.ServerPool.get_instance().del_server(2333)
    #    time.sleep(0.01)
    #"""
    while True:
        time.sleep(99999)