#!/usr/bin/python
# -*- coding: UTF-8 -*-

import logging
import redis
import time
import sys
import json
import Config

class RedisClient(object):

    instance = None
    DefaultExpireTime = 0
    DefaultOnlineKeyExpireTime = 300

    # def __init__(self):

    @staticmethod
    def getInstance():
        if RedisClient.instance is None:
            RedisClient.instance = redis.Redis(host=Config.REDIS_HOST,port=Config.REDIS_PORT,db=Config.REDIS_DB,password=Config.REDIS_PASS)
        return RedisClient.instance

    @staticmethod
    def GetUserInfo(port):
        key = RedisClient.genUserInfoKey(port)
        client = RedisClient.getInstance()
        val = client.get(key)
        if val is None or val=='':
            return None

        return json.loads(val)

    @staticmethod
    def StoreUserInfo(userInfo):
        key = RedisClient.genUserInfoKey(userInfo['Port'])
        client = RedisClient.getInstance()
        client.set(key,json.dumps(userInfo),RedisClient.DefaultExpireTime)

    @staticmethod
    def SetSize(port,size):
        key = RedisClient.genUserFlowKey(port)
        client = RedisClient.getInstance()
        client.set(key,size,RedisClient.DefaultExpireTime)

    @staticmethod
    def GetSize(port):
        key = RedisClient.genUserFlowKey(port)
        client = RedisClient.getInstance()
        if client.exists(key) is True:
            return client.get(key)
        return 0

    @staticmethod
    def IncrSize(port,size):
        key = RedisClient.genUserFlowKey(port)
        client = RedisClient.getInstance()
        if client.exists(key) is False:
            RedisClient.SetSize(port,size)
        else :
            client.incrby(key,size)
        RedisClient.MarkUserFlowChange(port)

    @staticmethod
    def MarkUserFlowChange(port):
        key = RedisClient.genPreUserFlowSortedSetKey()
        client = RedisClient.getInstance()
        client.zadd(key,port,time.time())

    @staticmethod
    def MarkUserOnline(port):
        key = RedisClient.genUserOnlineHashKey()
        client = RedisClient.getInstance()
        client.hset(key,port,time.time()+RedisClient.DefaultOnlineKeyExpireTime)

    @staticmethod
    def IsUserOnline(port):
        key = RedisClient.genUserOnlineHashKey()
        client = RedisClient.getInstance()
        if client.exists(key) is False:
            return False

	val = client.hget(key,port)

	if val <= time.time():
            client.hdel(key,port)
            return False

	return True

    @staticmethod
    def GetOnlineUsersCount():
        key = RedisClient.genUserOnlineHashKey()
        client = RedisClient.getInstance()
        if client.exists(key) is False :
            return False
        cnt = 0
        dict = client.hgetall(key)
        for (k,v) in  dict.items():
            if k == '' or v == '' :
                continue
            if v > time.time() :
                cnt = cnt + 1
        return cnt

    @staticmethod
    def SetUserAsEnable(port):
        key = RedisClient.genUserEnableSetKey()
        client = RedisClient.getInstance()
        client.sadd(key,port)

    @staticmethod
    def SetUserAsDisabled(port):
        key = RedisClient.genUserEnableSetKey()
        client = RedisClient.getInstance()
        client.srem(key,port)

    @staticmethod
    def GetUserPreEnableList():
        key = RedisClient.genUserPreEnableSetKey()
        client = RedisClient.getInstance()
        return client.smembers(key)

    @staticmethod
    def AddToUserPreEnableList(port):
        key = RedisClient.genUserPreEnableSetKey()
        client = RedisClient.getInstance()
        client.sadd(key,port)

    @staticmethod
    def RmFromUserPreEnableList(port):
        key = RedisClient.genUserPreEnableSetKey()
        client = RedisClient.getInstance()
        client.srem(key,port)

    @staticmethod
    def GetUserPreDisableList():
        key = RedisClient.genUserPreDisableSetKey()
        client = RedisClient.getInstance()
        return client.smembers(key)

    @staticmethod
    def RmFromUserPreDisableList(port):
        key = RedisClient.genUserPreDisableSetKey()
        client = RedisClient.getInstance()
        client.srem(key,port)

    @staticmethod
    def genUserInfoKey(port):
        # 生成用户信息KEY
        # "userInfo_n%s_p%s"
        return '{}{}'.format('userInfo_n0_p', port)

    @staticmethod
    def genUserFlowKey(port):
        # 生成用户流量 KEY
        # userFlow_n%s_p%s
    	return '{}{}'.format('userFlow_n0_p', port)

    @staticmethod
    def genUserEnableSetKey():
        # 已启用的用户集合KEY
        # userEnableSet_n%s
        return 'userEnableSet_n0'

    @staticmethod
    def genUserPreEnableSetKey():
        # 待启用的用户集合KEY
        # userPreEnableSet_n%s
        return 'userPreEnableSet_n0'

    @staticmethod
    def genUserPreDisableSetKey():
        # 待禁用的用户集合KEY
        # userPreDisableSet_n%s
        return 'userPreDisableSet_n0'

    @staticmethod
    def genUserOnlineHashKey():
        # 在线用户集合KEY
        # userOnlineHash_n%s
        return 'userOnlineHash_n0'

    @staticmethod
    def genPreUserFlowSortedSetKey():
        # 在线用户集合KEY
        # preUserFlow_n%s
        return 'preUserFlow_n0'