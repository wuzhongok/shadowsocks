#Config
MYSQL_HOST = 'localhost'
MYSQL_PORT = 3306
MYSQL_USER = 'sa_w'
MYSQL_PASS = 'k254trx#'
MYSQL_DB = 'db_wx'
MYSQL_TB = 'ssUser'


REDIS_HOST = 'localhost'
REDIS_PORT = '6370'
REDIS_PASS = 'ssr_go@2017'
REDIS_DB = 0

SERVER_NODE_ID = '1'

MANAGE_PASS = 's7000'
#if you want manage in other server you should set this value to global ip
MANAGE_BIND_IP = '127.0.0.1'
#make sure this port is idle
MANAGE_PORT = 7000